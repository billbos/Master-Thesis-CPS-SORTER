package org.zhaw.ch.ml;

public class WekaClassifier extends MachineLearningClassifier {

	public WekaClassifier() {
		classifierToolChain = "Weka";
	}
	
	
	public static void main(String[] args) {
		
		WekaClassifier wekaClassifier = new WekaClassifier();
		System.out.println("ClassifierToolChain: "+wekaClassifier.getClassifierToolChain());
		
	}
	
}
